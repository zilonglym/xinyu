package com.graby.zhongcangweb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.graby.zhongcangweb.entity.Company;
import com.graby.zhongcangweb.entity.Menu;
import com.graby.zhongcangweb.service.CompanyService;
import com.graby.zhongcangweb.service.MenuService;

@Controller
@RequestMapping(value = "/company")
public class CompanyController {
	
	@Autowired
	private CompanyService companyService;
	@Autowired
	private MenuService menuService;
	
	@RequestMapping(value="")
	public String CompanyWeb(HttpServletRequest request,ModelMap model){
		String menuId=request.getParameter("menuId");
		if (menuId==null) {
			menuId="2";
		}
		Map<String, Object> params=new HashMap<String, Object>();
		params.put("menuId", menuId);
		Company company=this.companyService.findCompanyByParams(params);
		model.addAttribute("company", company);
		List<Menu> menus=this.menuService.findAllMenus();
		model.addAttribute("menuList", menus);
		Menu menu=this.menuService.findMenuByParam(params);
		model.addAttribute("menu", menu);
		model.addAttribute("menuId", menuId);
		return "about";
	}
	
	@RequestMapping(value="blame")
	public String  BlameWeb(HttpServletRequest request,ModelMap model){
		String menuId=request.getParameter("menuId");
		if (menuId==null) {
			menuId="24";
		}
		Map<String, Object> params=new HashMap<String, Object>();
		params.put("menuId", menuId);
		Company company=this.companyService.findCompanyByParams(params);
		model.addAttribute("company", company);
		List<Menu> menus=this.menuService.findAllMenus();
		model.addAttribute("menuList", menus);
		Menu menu=this.menuService.findMenuByParam(params);
		model.addAttribute("menu", menu);
		return "blame";
	}
}
