package com.graby.zhongcangweb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.graby.zhongcangweb.entity.Contact;
import com.graby.zhongcangweb.entity.Menu;
import com.graby.zhongcangweb.service.ContactService;
import com.graby.zhongcangweb.service.MenuService;

@Controller
@RequestMapping(value="/contact")
public class ContactController {
	
	@Autowired
	private MenuService menuService;
	@Autowired
	private ContactService contactService;
	
	@RequestMapping(value="")
	public String WebContact(HttpServletRequest request,ModelMap model){
		String menuId=request.getParameter("menuId");
		if (menuId==null) {
			menuId="6";
		}
		Map<String, Object> param=new HashMap<String, Object>();
		param.put("menuId", menuId);
		List<Menu> menus=this.menuService.findAllMenus();
		model.addAttribute("menuList", menus);
		Menu menu=this.menuService.findMenuByParam(param);
		model.addAttribute("menu", menu);
		Contact contact=this.contactService.findContactByParams(param);
		model.addAttribute("contact", contact);
		return "contact";
	}
}
