package com.graby.zhongcangweb.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.graby.zhongcangweb.entity.Company;
import com.graby.zhongcangweb.entity.Menu;
import com.graby.zhongcangweb.entity.News;
import com.graby.zhongcangweb.service.CompanyService;
import com.graby.zhongcangweb.service.MenuService;
import com.graby.zhongcangweb.service.NewsService;

@Controller
@RequestMapping(value = "/home")
public class HomeController {
	
	@Autowired
	private CompanyService companyService;
	@Autowired
	private NewsService newsService;
	@Autowired
	private MenuService menuService;
	
	
	/**
	 * 网站首页
	 * */
	@RequestMapping(value = "")
	public String WebIndex(HttpServletRequest request,ModelMap model){
		Map<String,Object> params=new HashMap<String, Object>();
		params.put("menuId",7);
		Company company=this.companyService.findCompanyByParams(params);
		model.addAttribute("company", company);
		params.clear();
		params.put("start", 0);
		params.put("offset", 5);
		List<News> news=this.newsService.findNewsByParams(params);
		model.addAttribute("newsList", buildListData(news));
		List<Menu> menus=this.menuService.findAllMenus();
		model.addAttribute("menuList", menus);
		return "index";
	}

	private List<Map<String,Object>> buildListData(List<News> newsList) {
		List<Map<String, Object>> results=new ArrayList<Map<String,Object>>();
		for(News news:newsList){
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("title", news.getTitle());
			SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd");
			map.put("lastUpdate", sf.format(news.getLastUpdate()));
			results.add(map);
		}
		return results;
	}
}
