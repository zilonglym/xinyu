package com.graby.zhongcangweb.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.graby.zhongcangweb.entity.Menu;
import com.graby.zhongcangweb.entity.News;
import com.graby.zhongcangweb.service.MenuService;
import com.graby.zhongcangweb.service.NewsService;

@Controller
@RequestMapping(value = "/news")
public class NewsController {

	@Autowired
	private MenuService menuService;
	@Autowired
	private NewsService newsService;
	
	@RequestMapping(value="")
	public String WebNews(HttpServletRequest request,ModelMap model){
		String menuId=request.getParameter("menuId");
		if (menuId==null) {
			menuId="3";
		}
		Map<String, Object> param=new HashMap<String, Object>();
		param.put("menuId", menuId);
		List<News> news=this.newsService.findNewsByParams(param);
		model.addAttribute("newsList", buildListData(news));
//		System.err.println(buildListData(news));
		List<Menu> menus=this.menuService.findAllMenus();
		model.addAttribute("menuList", menus);
		Menu menu=this.menuService.findMenuByParam(param);
		model.addAttribute("menu", menu);
		return "news";
	}

	private List<Map<String, Object>> buildListData(List<News> newsList) {
		List<Map<String, Object>>results=new ArrayList<Map<String,Object>>();
		for(News news:newsList){
			Map<String, Object> map=new HashMap<String, Object>();
			map.put("menuId", news.getMenuId());
			map.put("id", news.getId());
			map.put("title", news.getTitle());
			SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd");
			map.put("lastUpdate", "["+sf.format(news.getLastUpdate())+"]");
//			System.err.println(sf.format(news.getLastUpdate()));
			results.add(map);
		}
		return results;
	}
	
	@RequestMapping(value="browse")
	public String BrowseNews(HttpServletRequest request,ModelMap model){
		String id=request.getParameter("id");
//		System.err.println(id);
		News news=this.newsService.findNewsById(Integer.parseInt(id));
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("title", news.getTitle());
		map.put("content", news.getContent());
		map.put("menuId", news.getMenuId());
		SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		map.put("lastUpdate", sf.format(news.getLastUpdate()));
		map.put("source", news.getSource());
		model.addAttribute("news", map);
		List<Menu> menus=this.menuService.findAllMenus();
		model.addAttribute("menuList", menus);
		Map<String, Object> param=new HashMap<String, Object>();
		param.put("menuId", news.getMenuId());
		Menu menu=this.menuService.findMenuByParam(param);
		model.addAttribute("menu", menu);
		//System.err.println(map);
		return "browse_news";
	}
}
