package com.graby.zhongcangweb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.graby.zhongcangweb.entity.Menu;
import com.graby.zhongcangweb.entity.Recurit;
import com.graby.zhongcangweb.service.MenuService;
import com.graby.zhongcangweb.service.RecuritService;

/**
 * 人才中心
 * */
@Controller
@RequestMapping(value = "/jobs")
public class RecuritController {
	
	@Autowired
	private MenuService menuService;
	@Autowired
	private RecuritService recuritService;
	
	@RequestMapping(value="")
	public String WebRecurit(HttpServletRequest request,ModelMap model){
		String menuId=request.getParameter("menuId");
		if (menuId==null) {
			menuId="5";
		}
		Map<String, Object> params=new HashMap<String, Object>();
		params.put("menuId", menuId);
		List<Menu> menus=this.menuService.findAllMenus();
		model.addAttribute("menuList", menus);
		Menu menu=this.menuService.findMenuByParam(params);
		model.addAttribute("menu", menu);
		Recurit recurit=this.recuritService.findRecuritByParams(params);
		model.addAttribute("recurit", recurit);
		return "jobs";
	}
}
