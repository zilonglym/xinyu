package com.graby.zhongcangweb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.graby.zhongcangweb.entity.Company;
import com.graby.zhongcangweb.entity.Menu;
import com.graby.zhongcangweb.entity.News;
import com.graby.zhongcangweb.entity.ServiceOfCompany;
import com.graby.zhongcangweb.service.MenuService;
import com.graby.zhongcangweb.service.ServiceOfCompanyService;

/**
 * 公司服务
 * */
@Controller
@RequestMapping(value = "/serviceOfCompany")
public class ServiceOfCompanyController {
	
	@Autowired
	private ServiceOfCompanyService serviceOfCompanyservice;
	@Autowired
	private MenuService menuService;
	
	@RequestMapping(value="")
	public String WebServiceOfCompany(HttpServletRequest request,ModelMap model){
		String menuId=request.getParameter("menuId");
		if (menuId==null) {
			menuId="4";
		}
		Map<String,Object> params=new HashMap<String, Object>();
		params.put("menuId",menuId);
		List<ServiceOfCompany> serviceOfCompanys =this.serviceOfCompanyservice.findServiceListByParam(params);
		model.addAttribute("serviceOfCompanys", serviceOfCompanys);
		List<Menu> menus=this.menuService.findAllMenus();
		model.addAttribute("menuList", menus);
		Menu menu=this.menuService.findMenuByParam(params);
		model.addAttribute("menu", menu);
		return "companyService";
	}
}
