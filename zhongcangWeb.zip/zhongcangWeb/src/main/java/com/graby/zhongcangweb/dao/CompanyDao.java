package com.graby.zhongcangweb.dao;

import java.util.List;
import java.util.Map;

import com.graby.zhongcangweb.entity.Company;
import com.graby.zhongcangweb.util.MyBatisRepository;

@MyBatisRepository
public interface CompanyDao {
	
	Company findCompanyByParams(Map<String, Object> params);

	List<Company> findCompanyListByParams(Map<String, Object> params);
	
}
