package com.graby.zhongcangweb.dao;

import java.util.List;
import java.util.Map;

import com.graby.zhongcangweb.entity.Menu;
import com.graby.zhongcangweb.util.MyBatisRepository;

@MyBatisRepository
public interface MenuDao {

	List<Menu> findAllMenus();

	Menu findMenuByParam(Map<String, Object> params);

}
