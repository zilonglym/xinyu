package com.graby.zhongcangweb.dao;

import java.util.List;
import java.util.Map;

import com.graby.zhongcangweb.entity.News;
import com.graby.zhongcangweb.util.MyBatisRepository;

@MyBatisRepository
public interface NewsDao {

	List<News> findNewsByParams(Map<String, Object> params);

	News findNewsById(int id);

}
