package com.graby.zhongcangweb.dao;

import java.util.Map;

import com.graby.zhongcangweb.entity.Recurit;
import com.graby.zhongcangweb.util.MyBatisRepository;

@MyBatisRepository
public interface RecuritDao {

	Recurit findRecuritByParams(Map<String, Object> params);

}
