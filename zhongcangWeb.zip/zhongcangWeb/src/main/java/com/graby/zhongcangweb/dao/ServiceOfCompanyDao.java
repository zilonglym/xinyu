package com.graby.zhongcangweb.dao;

import java.util.List;
import java.util.Map;

import com.graby.zhongcangweb.entity.ServiceOfCompany;
import com.graby.zhongcangweb.util.MyBatisRepository;

@MyBatisRepository
public interface ServiceOfCompanyDao {

	List<ServiceOfCompany> findServiceListByParam(Map<String, Object> params);

}
