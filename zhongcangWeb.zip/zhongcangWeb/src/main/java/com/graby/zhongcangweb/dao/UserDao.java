package com.graby.zhongcangweb.dao;

public interface UserDao {

}
