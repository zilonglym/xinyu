package com.graby.zhongcangweb.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 公司服务
 * */
@Entity
@Table(name = "tb_service")
public class ServiceOfCompany implements Serializable{
	
private static final long serialVersionUID = 2617282959202191953L;
	
	private int id;
	//对应菜单ID
	private int menuId;
	//文本标题
	private String title;
	//图片信息内容
	private String description;
	//信息创建时间
	private Date createDate;
	//信息更新时间
	private Date lastUpdate;
	//图片名
	private String fileName;
	//图片类型
//	private String fileType;
	//图片文件大小
//	private String fileSize;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getMenuId() {
		return menuId;
	}
	public void setMenuId(int menuId) {
		this.menuId = menuId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getLastUpdate() {
		return lastUpdate;
	}
	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
//	public String getFileType() {
//		return fileType;
//	}
//	public void setFileType(String fileType) {
//		this.fileType = fileType;
//	}
//	public String getFileSize() {
//		return fileSize;
//	}
//	public void setFileSize(String fileSize) {
//		this.fileSize = fileSize;
//	}
	
}
