package com.graby.zhongcangweb.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.graby.zhongcangweb.dao.CompanyDao;
import com.graby.zhongcangweb.entity.Company;

@Component
@Transactional
public class CompanyService {

	@Autowired
	private CompanyDao companyDao;
	
	public Company findCompanyByParams(Map<String, Object> params){
		return this.companyDao.findCompanyByParams(params);
	}

	public List<Company> findCompanyListByParams(Map<String, Object> params) {
		return this.companyDao.findCompanyListByParams(params);
	}

}
