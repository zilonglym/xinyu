package com.graby.zhongcangweb.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.graby.zhongcangweb.dao.ContactDao;
import com.graby.zhongcangweb.entity.Contact;

@Component
@Transactional
public class ContactService {

	@Autowired
	private ContactDao contactDao;
	
	public Contact findContactByParams(Map<String, Object> param){
		return this.contactDao.findContactByParams(param);
	}

}
