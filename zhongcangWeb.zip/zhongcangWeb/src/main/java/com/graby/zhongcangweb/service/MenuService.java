package com.graby.zhongcangweb.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.graby.zhongcangweb.dao.MenuDao;
import com.graby.zhongcangweb.entity.Menu;

@Component
@Transactional
public class MenuService {

	@Autowired
	private MenuDao menuDao;
	
	public List<Menu> findAllMenus(){
		return this.menuDao.findAllMenus();
	}

	public Menu findMenuByParam(Map<String, Object> params) {
		return this.menuDao.findMenuByParam(params);
	}

}
