package com.graby.zhongcangweb.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.graby.zhongcangweb.dao.NewsDao;
import com.graby.zhongcangweb.entity.News;

@Component
@Transactional
public class NewsService {

	@Autowired
	private NewsDao newsDao;
	
	public List<News> findNewsByParams(Map<String, Object> params){
		return this.newsDao.findNewsByParams(params);
	}

	public News findNewsById(int id) {
		return this.newsDao.findNewsById(id);
	}

}
