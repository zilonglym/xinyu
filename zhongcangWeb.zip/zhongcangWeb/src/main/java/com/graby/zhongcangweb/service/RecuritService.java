package com.graby.zhongcangweb.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.graby.zhongcangweb.dao.RecuritDao;
import com.graby.zhongcangweb.entity.Recurit;

@Component
@Transactional
public class RecuritService {
	
	@Autowired
	private RecuritDao recuritDao;
	
	public Recurit findRecuritByParams(Map<String, Object> params){
		return this.recuritDao.findRecuritByParams(params);
	}

}
